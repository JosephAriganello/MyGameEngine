#include "CollisionHandler.h"
#include "../Core/Engine.h"

std::unique_ptr<CollisionHandler> CollisionHandler::collisionInstance = nullptr;
std::vector<GameObject*> CollisionHandler::colliders = std::vector<GameObject*>();
std::vector<GameObject*> CollisionHandler::previousCollisions = std::vector<GameObject*>();

CollisionHandler::CollisionHandler(){

}

CollisionHandler::~CollisionHandler(){
	if (colliders.size() > 0) {
		for (auto go : colliders) {
			go = nullptr;
		}

		colliders.clear();
		colliders.shrink_to_fit();
	}
}

CollisionHandler* CollisionHandler::GetInstance(){
	if (collisionInstance.get() == nullptr) {
		collisionInstance.reset(new CollisionHandler);
	}

	return collisionInstance.get();
}

void CollisionHandler::Initialize(){
	previousCollisions.clear();
	previousCollisions.shrink_to_fit();

	colliders.clear();
	colliders.shrink_to_fit();
}

void CollisionHandler::AddObject(GameObject* go_){
	colliders.push_back(go_);
}

void CollisionHandler::Update(glm::vec2 mousePos_, int buttonType_){

}
